CHANGELOG
=========

## HEAD (Unreleased)
* Prepare for 2.0 release
* Add prepare command to rename the `scaleway` occurrences

---

